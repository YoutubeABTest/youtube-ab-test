import json
import os
import urllib.parse

def lambda_handler(event, context ):
    # Handle different HTTP methods and paths
    http_method = event.get('httpMethod', 'GET' )
    path = event.get('path', '/')
    
    # CORS headers
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    
    # Handle OPTIONS requests (CORS preflight)
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    # Handle login route
    if path == '/login':
        # Google OAuth URL
        client_id = os.getenv('GOOGLE_CLIENT_ID' )
        redirect_uri = 'https://xa0etg74tg.execute-api.us-east-1.amazonaws.com/prod/callback'
        
        oauth_url = (
            f"https://accounts.google.com/o/oauth2/auth?"
            f"client_id={client_id}&"
            f"redirect_uri={urllib.parse.quote(redirect_uri )}&"
            f"scope=https://www.googleapis.com/auth/youtube.readonly&"
            f"response_type=code&"
            f"access_type=offline"
         )
        
        # Redirect to Google OAuth
        return {
            'statusCode': 302,
            'headers': {
                'Location': oauth_url,
                'Access-Control-Allow-Origin': '*'
            },
            'body': ''
        }
    
    # Handle callback route (placeholder)
    if path == '/callback':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'message': 'OAuth callback received',
                'query_params': event.get('queryStringParameters', {})
            })
        }
    
    # Main API response for root path
    response_body = {
        'message': 'YouTube A/B Testing Tool API',
        'version': '1.0.0',
        'status': 'running',
        'environment': {
            'google_client_id_set': bool(os.getenv('GOOGLE_CLIENT_ID')),
            'google_client_secret_set': bool(os.getenv('GOOGLE_CLIENT_SECRET'))
        },
        'path': path,
        'method': http_method
    }
    
    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps(response_body )
    }
